# Gaussian-process emulation of a Gaussian plume model with sequential experimental design

A small, self-contained study of a core problem in computer experiments:
**when a simulator is expensive, which runs should you spend your budget on?**

A Gaussian plume dispersion model (the "simulator") is emulated with a
Gaussian process (GP). Four ways of choosing the training runs are compared:
random sampling, Latin hypercube designs, and two sequential
(active-learning) criteria.

The plume model is cheap, which makes it a convenient test bench: the true
simulator output is available everywhere, so emulator error can be measured
exactly. The same workflow carries over to simulators that take hours per run
(e.g. climate or chemistry-transport models).

## Simulator

Ground-level, centre-line concentration downwind of an elevated point source
with ground reflection, using Briggs (1973) open-country dispersion
coefficients for Pasquill–Gifford stability classes. The discrete stability
class is replaced by a continuous index so that the input space is a smooth
4-D hypercube:

| input | symbol | range |
|---|---|---|
| wind speed | u | 1 – 10 m/s |
| effective stack height | H | 10 – 60 m |
| downwind distance | x | 500 – 5000 m |
| stability index | s | 0 (class A) – 4 (class E) |

The emulated output is `log10` of concentration. The ranges exclude the region
where concentration underflows to essentially zero (tall stacks in stable air
close to the source); including it makes the log-concentration surface
unlearnable for a stationary GP (an early version of this study did exactly
that, with log10 C reaching -112).

## Emulator

`scikit-learn` GP regression with an anisotropic (ARD) Matérn-5/2 kernel plus
a small nugget, outputs standardised, hyper-parameters re-fitted by maximum
likelihood after every new run.

## Design strategies

All methods use the same GP. Sequential methods start from the same 10-point
Latin hypercube and add one run at a time from a 1024-point Sobol candidate
pool.

* **random**: uniformly random points (nested).
* **lhs**: a new Latin hypercube of size n at every budget n (not sequential).
* **alm**: add the candidate with the largest predictive variance.
* **alc**: add the candidate that most reduces the average predictive variance
  over a 256-point reference set (integrated-variance criterion, Cohn 1996).

Metric: RMSE of `log10 C` on 2000 held-out Latin-hypercube test points.
10 independent repetitions (different initial designs, pools and random
points); the test set is fixed.

## Results

Mean test RMSE of log10 concentration (10 repetitions):

| n | random | lhs | alm | alc |
|---|---|---|---|---|
| 20 | 0.151 | 0.125 | 0.189 | **0.119** |
| 30 | 0.116 | 0.096 | 0.146 | **0.092** |
| 40 | 0.098 | **0.088** | 0.145 | **0.087** |
| 50 | 0.084 | 0.087 | 0.113 | **0.067** |
| 60 | 0.076 | 0.072 | 0.093 | **0.061** |

![learning curves](results/learning_curve.png)

![parity and design points](results/design_and_parity.png)

What the experiment shows:

1. **ALC is the best strategy at most budgets.** At n = 60 its RMSE is about
   20% lower than random sampling and about 15% lower than a fresh Latin
   hypercube. The advantage over LHS is small at moderate n (n = 40) and the
   standard-error bands overlap at several budgets, so with 10 repetitions this
   should be read as a consistent trend rather than a precise effect size.
2. **Maximum-variance sampling (ALM) is worse than random sampling** here.
   The right-hand panels show why: ALM places many points on the faces and
   corners of the input space, where predictive variance is naturally largest,
   but these points are less informative for the interior than points chosen by
   ALC.
3. At n = 10 the sequential methods and the random/LHS baselines do **not**
   share a design (the sequential ones start from one fixed LHS), so the n = 10
   row is not a like-for-like comparison.

## Limitations

* The simulator is cheap, smooth and has only 4 inputs. Gains from sequential
  design may differ for noisy, higher-dimensional or non-stationary simulators.
* The largest emulator errors (parity plot) are at the extreme high-concentration
  corner (low wind, low stack, short distance, unstable air), where the
  response is steep and the design is sparse.
* Hyper-parameters are re-estimated at every step; this is standard but can
  be unstable for very small n.
* Only global accuracy is targeted. Goal-oriented designs (e.g. accuracy near an
  exceedance threshold such as a regulatory limit) are not covered.
* Batch (parallel) selection, heteroscedastic noise and multi-output emulation
  are not implemented.

## Reproduce

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pytest -q                   # unit tests for the simulator
python run_experiment.py    # ~minutes; writes results/*.csv and *.png
```

## Structure

```
src/plume.py          Gaussian plume simulator (Briggs dispersion coefficients)
src/emulator.py       GP model, Latin hypercube, ALM and ALC criteria
run_experiment.py     Comparison of design strategies, figures, tables
tests/test_plume.py   Sanity checks for the simulator
results/              CSV tables and figures produced by run_experiment.py
```

## References

* Briggs, G. A. (1973). *Diffusion estimation for small emissions.* ATDL Contribution File No. 79-15, NOAA.
* Rasmussen, C. E. & Williams, C. K. I. (2006). *Gaussian Processes for Machine Learning.* MIT Press.
* Cohn, D. A. (1996). Neural network exploration using optimal experiment design. *Neural Networks*, 9(6), 1071–1083.
* Santner, T. J., Williams, B. J. & Notz, W. I. (2003). *The Design and Analysis of Computer Experiments.* Springer.

## Author

Amin Khademi
