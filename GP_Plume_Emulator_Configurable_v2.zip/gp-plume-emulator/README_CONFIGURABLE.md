# Configurable Gaussian Plume GP Emulator

A configurable extension of the supplied research code. It retains the original Gaussian plume formulation and the four design strategies (random, LHS, ALM, ALC), while exposing experiment settings through `config.json`.

## Windows quick start
1. Install Python 3.10 or newer from python.org and enable **Add Python to PATH**.
2. Extract this ZIP to a normal writable folder.
3. Double-click `run_windows.bat`. On first run it creates `.venv`, installs requirements, and starts the experiment.
4. Later runs can use `run_windows_quick.bat`.

## Configure the experiment
Edit `config.json` before running:

- `bounds`: four pairs `[minimum, maximum]` for wind speed (m/s), effective stack height (m), downwind distance (m), and stability index (0–4).
- `include_emission_rate`: set `true` to add emission rate Q as a fifth GP input.
- `emission_rate_bounds_g_s`: min/max Q (g/s), used only when Q is enabled.
- `fixed_emission_rate_g_s`: fixed Q (g/s), used when Q is not an input.
- `methods`: any subset of `random`, `lhs`, `alm`, `alc`.
- `kernel`: `matern52`, `matern32`, or `rbf`.
- `optimizer_restarts`, `nugget`: GP fitting settings.
- `initial_samples`, `max_samples`, `sample_step`, `repetitions`: experimental design budget.
- `test_samples`, `candidate_pool`, `reference_points`: evaluation and active-learning sizes.
- `seed`: reproducibility seed; `output_dir`: result folder.

The model maps unit-hypercube designs to the physical bounds in the configuration. Stability remains continuous from 0 (A) to 4 (E), as in the original study.

## Command line
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python run_experiment.py --config config.json
```

Create a fresh default settings file with:
```bash
python run_experiment.py --init-config
```

## Outputs
The selected output folder contains:
- `results.csv`: RMSE for every repetition, method and sample budget.
- `summary.csv`: mean and standard deviation of RMSE.
- `mean_rmse_table.csv`: pivoted mean-RMSE table.
- `learning_curve.png`: comparison plot.
- `run_config.json`: exact settings used for the run.

The reported target is **log10 ground-level centreline concentration**. This is a forward model, not inverse source estimation. The current plume physics remain the original idealised Briggs open-country model; changing parameter bounds does not make the physics valid outside its assumptions. Adding Q as an input changes the emulator input space to five dimensions, but Q only scales the concentration in this formulation.

## Important limitations
- The receptor is at ground level and on the plume centreline.
- The stability input is a continuous interpolation from A to E, not a full meteorological stability solver.
- Wind direction, terrain, deposition, chemistry, time-varying meteorology and 2-D/3-D concentration fields are not represented.
- ALC uses a full posterior covariance matrix and can be computationally expensive for large candidate/reference sets.
- GP hyperparameters are optimised by scikit-learn's likelihood optimiser; this is not an exhaustive hyperparameter search.

## Tests
```bash
pytest -q
```
