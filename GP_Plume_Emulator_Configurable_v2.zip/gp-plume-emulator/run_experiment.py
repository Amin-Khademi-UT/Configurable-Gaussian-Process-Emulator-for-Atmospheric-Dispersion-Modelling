"""Configurable GP emulator experiment for the Gaussian plume simulator."""
from __future__ import annotations
import argparse, json, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import qmc
sys.path.insert(0, str(Path(__file__).parent / "src"))
from plume import PlumeSimulator
from emulator import lhs, fit, rmse, active_step, alc_step

ROOT = Path(__file__).parent
DEFAULT_CONFIG = {
  "bounds": [[1,10],[10,60],[500,5000],[0,4]],
  "include_emission_rate": False, "emission_rate_bounds_g_s": [0.1,10.0], "fixed_emission_rate_g_s": 1.0,
  "methods": ["random","lhs","alm","alc"], "kernel": "matern52", "optimizer_restarts": 2, "nugget": 1e-6,
  "initial_samples": 10, "max_samples": 60, "sample_step": 5, "repetitions": 5,
  "test_samples": 1000, "candidate_pool": 512, "reference_points": 128, "seed": 42,
  "output_dir": "results_custom"
}


def load_config(path):
    if not path: return DEFAULT_CONFIG.copy()
    with open(path, encoding="utf-8") as f: cfg=json.load(f)
    merged=DEFAULT_CONFIG.copy(); merged.update(cfg); return merged


def validate(c):
    if not set(c["methods"]).issubset({"random","lhs","alm","alc"}) or not c["methods"]: raise ValueError("methods must be chosen from random/lhs/alm/alc")
    if c["kernel"] not in {"matern52","matern32","rbf"}: raise ValueError("Unsupported kernel")
    if not (2 <= c["initial_samples"] <= c["max_samples"]): raise ValueError("Require 2 <= initial_samples <= max_samples")
    if c["sample_step"] < 1 or c["repetitions"] < 1 or c["test_samples"] < 10: raise ValueError("Invalid sample/repetition/test settings")
    if c["candidate_pool"] < 10 or c["reference_points"] < 10: raise ValueError("Candidate/reference pools must be at least 10")


def run(c):
    validate(c)
    sim=PlumeSimulator(c["bounds"], c["include_emission_rate"], c["emission_rate_bounds_g_s"], c["fixed_emission_rate_g_s"])
    out=ROOT / c["output_dir"]; out.mkdir(parents=True, exist_ok=True)
    test=lhs(c["test_samples"],sim.dim,c["seed"]+12345); ytest=sim(test)
    budgets=list(range(c["initial_samples"],c["max_samples"]+1,c["sample_step"]))
    if budgets[-1] != c["max_samples"]: budgets.append(c["max_samples"])
    rows=[]; started=time.time()
    for seed in range(c["repetitions"]):
        rng=np.random.default_rng(c["seed"]+seed)
        pool=qmc.Sobol(d=sim.dim,scramble=True,seed=c["seed"]+seed).random(c["candidate_pool"])
        ref=qmc.Sobol(d=sim.dim,scramble=True,seed=c["seed"]+500+seed).random(c["reference_points"])
        xrand=rng.random((c["max_samples"],sim.dim))
        x0=lhs(c["initial_samples"],sim.dim,c["seed"]+1000+seed)
        # Baseline designs are fitted independently at each requested budget.
        for method in c["methods"]:
            if method in ("random","lhs"):
                for n in budgets:
                    X=xrand[:n] if method=="random" else lhs(n,sim.dim,c["seed"]+2000+100*seed+n)
                    gp=fit(X,sim(X),c["seed"]+seed,c["kernel"],c["optimizer_restarts"],c["nugget"])
                    rows.append({"seed":seed,"n":n,"method":method,"rmse":rmse(gp,test,ytest)})
            else:
                X=x0.copy(); y=sim(X); used=set(); checkpoints=set(budgets)
                for n in range(c["initial_samples"],c["max_samples"]+1):
                    gp=fit(X,y,c["seed"]+seed,c["kernel"],c["optimizer_restarts"],c["nugget"])
                    if n in checkpoints: rows.append({"seed":seed,"n":n,"method":method,"rmse":rmse(gp,test,ytest)})
                    if n==c["max_samples"]: break
                    j=active_step(gp,pool,used) if method=="alm" else alc_step(gp,pool,ref,used)
                    used.add(j); X=np.vstack([X,pool[j]]); y=np.append(y,sim(pool[j]))
        print(f"Repetition {seed+1}/{c['repetitions']} complete",flush=True)
    df=pd.DataFrame(rows); df.to_csv(out/"results.csv",index=False)
    summary=df.groupby(["method","n"])["rmse"].agg(["mean","std"]).reset_index(); summary.to_csv(out/"summary.csv",index=False)
    summary.pivot(index="n",columns="method",values="mean").to_csv(out/"mean_rmse_table.csv")
    # Plot learning curves and uncertainty bands.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8,5))
    for method in c["methods"]:
        sub=summary[summary.method==method].sort_values("n")
        se=sub["std"].fillna(0)/np.sqrt(c["repetitions"])
        ax.plot(sub.n,sub["mean"],marker="o",label=method)
        ax.fill_between(sub.n,sub["mean"]-se,sub["mean"]+se,alpha=.15)
    ax.set(xlabel="Training simulator runs",ylabel="Test RMSE of log10 concentration",title="Gaussian-process plume emulator: learning curves")
    ax.grid(alpha=.25); ax.legend(); fig.tight_layout(); fig.savefig(out/"learning_curve.png",dpi=160); plt.close(fig)
    with open(out/"run_config.json","w",encoding="utf-8") as f: json.dump(c,f,indent=2)
    print("\nMean RMSE by method and sample budget:")
    print(summary.pivot(index="n",columns="method",values="mean").round(5).to_string())
    print(f"\nSaved outputs to: {out.resolve()}  | elapsed: {time.time()-started:.1f}s")


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config",default="config.json",help="JSON settings file (default: config.json)")
    p.add_argument("--init-config",action="store_true",help="write a default config.json and exit")
    p.add_argument("--output-dir",help="override output directory")
    args=p.parse_args()
    if args.init_config:
        with open(args.config,"w",encoding="utf-8") as f: json.dump(DEFAULT_CONFIG,f,indent=2)
        print(f"Created {args.config}"); return
    cfg=load_config(args.config if Path(args.config).exists() else None)
    if args.output_dir: cfg["output_dir"]=args.output_dir
    run(cfg)
if __name__=="__main__": main()
