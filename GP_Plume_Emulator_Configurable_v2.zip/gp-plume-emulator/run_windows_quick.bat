@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Run run_windows.bat once first to install dependencies.
 pause
 exit /b 1
)
.venv\Scripts\python.exe run_experiment.py --config config.json
pause
