"""Gaussian-process emulator and experimental-design strategies."""
import warnings
import numpy as np
from scipy.stats import qmc
from sklearn.exceptions import ConvergenceWarning
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern, RBF, WhiteKernel
warnings.filterwarnings("ignore", category=ConvergenceWarning)


def make_gp(dim=4, kernel_name="matern52", restarts=2, nugget=1e-6, seed=0):
    if kernel_name == "matern52": base = Matern(length_scale=np.ones(dim), length_scale_bounds=(1e-2, 1e2), nu=2.5)
    elif kernel_name == "matern32": base = Matern(length_scale=np.ones(dim), length_scale_bounds=(1e-2, 1e2), nu=1.5)
    elif kernel_name == "rbf": base = RBF(length_scale=np.ones(dim), length_scale_bounds=(1e-2, 1e2))
    else: raise ValueError("kernel_name must be matern52, matern32 or rbf")
    kernel = ConstantKernel(1.0, (1e-2, 1e3)) * base + WhiteKernel(nugget, (1e-10, 1e-2))
    return GaussianProcessRegressor(kernel, normalize_y=True, n_restarts_optimizer=int(restarts), random_state=seed)


def lhs(n, dim, seed): return qmc.LatinHypercube(d=dim, seed=seed).random(n)
def fit(X, y, seed=0, kernel="matern52", restarts=2, nugget=1e-6):
    return make_gp(X.shape[1], kernel, restarts, nugget, seed).fit(X, y)
def rmse(gp, X_test, y_test): return float(np.sqrt(np.mean((gp.predict(X_test)-y_test)**2)))


def active_step(gp, X_pool, used):
    _, std = gp.predict(X_pool, return_std=True)
    if used: std[list(used)] = -np.inf
    return int(np.argmax(std))


def alc_step(gp, X_pool, X_ref, used):
    Z = np.vstack([X_pool, X_ref])
    _, cov = gp.predict(Z, return_cov=True)
    n = len(X_pool)
    cross = cov[:n, n:]
    score = (cross**2).mean(axis=1) / np.maximum(np.diag(cov)[:n], 1e-12)
    if used: score[list(used)] = -np.inf
    return int(np.argmax(score))
