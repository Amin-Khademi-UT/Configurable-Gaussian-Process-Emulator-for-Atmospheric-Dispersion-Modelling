"""Configurable Gaussian plume simulator (ground-level centreline receptor)."""
import numpy as np

BASE_NAMES = ["wind_speed", "stack_height", "distance", "stability"]
BASE_LABELS = ["Wind speed u (m/s)", "Effective stack height H (m)", "Downwind distance x (m)", "Stability index s (0=A ... 4=E)"]
DEFAULT_BOUNDS = [[1.0, 10.0], [10.0, 60.0], [500.0, 5000.0], [0.0, 4.0]]


def _sigma_y_class(x, k):
    a = (0.22, 0.22, 0.16, 0.11, 0.08, 0.08)[k]
    return a * x / np.sqrt(1.0 + 0.0001 * x)


def _sigma_z_class(x, k):
    if k == 0: return 0.20 * x
    if k == 1: return 0.12 * x
    if k == 2: return 0.08 * x / np.sqrt(1.0 + 0.0002 * x)
    if k == 3: return 0.06 * x / np.sqrt(1.0 + 0.0015 * x)
    if k == 4: return 0.03 * x / (1.0 + 0.0003 * x)
    return 0.016 * x / (1.0 + 0.0003 * x)


def sigmas(x, s):
    x = np.asarray(x, dtype=float)
    s = np.clip(np.asarray(s, dtype=float), 0.0, 4.0)
    i = np.minimum(np.floor(s).astype(int), 3)
    w = s - i
    xb, ib, wb = np.broadcast_arrays(x, i, w)
    sy, sz = np.empty(xb.shape), np.empty(xb.shape)
    for k in range(4):
        mask = ib == k
        if np.any(mask):
            xm, wm = xb[mask], wb[mask]
            sy[mask] = _sigma_y_class(xm, k) ** (1-wm) * _sigma_y_class(xm, k+1) ** wm
            sz[mask] = _sigma_z_class(xm, k) ** (1-wm) * _sigma_z_class(xm, k+1) ** wm
    return sy, sz


def concentration(u, H, x, s, Q=1.0):
    """Ground-level centreline concentration in ug/m3; Q is in g/s."""
    u, H, x, s, Q = np.broadcast_arrays(u, H, x, s, Q)
    if np.any(u <= 0) or np.any(x <= 0) or np.any(H < 0) or np.any(Q <= 0):
        raise ValueError("u, x and Q must be positive; H must be non-negative")
    sy, sz = sigmas(x, s)
    return Q * 1e6 / (np.pi * u * sy * sz) * np.exp(-H**2 / (2.0 * sz**2))


class PlumeSimulator:
    """Maps unit-hypercube inputs to log10 concentration.

    Q is either fixed or an additional fifth emulator input. Q bounds are g/s.
    """
    def __init__(self, bounds=None, include_q=False, q_bounds=(0.1, 10.0), q_fixed=1.0):
        self.bounds = np.asarray(bounds if bounds is not None else DEFAULT_BOUNDS, dtype=float)
        if self.bounds.shape != (4, 2) or np.any(self.bounds[:, 1] <= self.bounds[:, 0]):
            raise ValueError("bounds must contain four [min, max] pairs with max > min")
        if self.bounds[0, 0] <= 0 or self.bounds[1, 0] < 0 or self.bounds[2, 0] <= 0:
            raise ValueError("wind speed and distance bounds must be positive; stack height must be non-negative")
        if self.bounds[3, 0] < 0 or self.bounds[3, 1] > 4:
            raise ValueError("stability bounds must remain within 0 (A) and 4 (E)")
        self.include_q = bool(include_q)
        self.q_bounds = tuple(map(float, q_bounds))
        self.q_fixed = float(q_fixed)
        if self.include_q and (self.q_bounds[0] <= 0 or self.q_bounds[1] <= self.q_bounds[0]):
            raise ValueError("Q bounds must be positive and increasing")
        if self.q_fixed <= 0: raise ValueError("fixed Q must be positive")
        self.dim = 5 if self.include_q else 4

    def physical_inputs(self, X_unit):
        X_unit = np.atleast_2d(np.asarray(X_unit, dtype=float))
        if X_unit.shape[1] != self.dim: raise ValueError(f"Expected {self.dim} input columns")
        if np.any((X_unit < 0) | (X_unit > 1)): raise ValueError("Unit inputs must be in [0, 1]")
        vals = self.bounds[:, 0] + X_unit[:, :4] * (self.bounds[:, 1] - self.bounds[:, 0])
        if self.include_q:
            q = self.q_bounds[0] + X_unit[:, 4] * (self.q_bounds[1] - self.q_bounds[0])
        else:
            q = np.full(len(X_unit), self.q_fixed)
        return vals, q

    def __call__(self, X_unit):
        vals, q = self.physical_inputs(X_unit)
        u, H, x, s = vals.T
        sy, sz = sigmas(x, s)
        # Analytic log expression avoids numerical underflow.
        return (np.log10(q) + np.log10(1e6 / (np.pi * u * sy * sz))
                - H**2 / (2.0 * sz**2) / np.log(10.0))


def simulator(X_unit):
    """Backward-compatible original 4-D simulator with Q=1 g/s."""
    return PlumeSimulator()(X_unit)
