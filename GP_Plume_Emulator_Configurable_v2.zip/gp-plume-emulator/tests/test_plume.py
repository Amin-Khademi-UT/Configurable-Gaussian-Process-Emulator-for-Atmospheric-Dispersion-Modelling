import numpy as np
import pytest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from plume import PlumeSimulator, concentration, simulator


def test_original_simulator_shape_and_finite():
    y=simulator(np.array([[0.5,0.5,0.5,0.5],[0.2,0.3,0.7,0.1]]))
    assert y.shape==(2,) and np.all(np.isfinite(y))


def test_emission_rate_scales_log_concentration():
    X=np.array([[0.4,0.4,0.4,0.4,0.0]])
    sim1=PlumeSimulator(include_q=True,q_bounds=(1,10))
    X[0,4]=0
    y1=sim1(X)
    X[0,4]=1
    y10=sim1(X)
    assert np.allclose(y10-y1,1.0)


def test_concentration_positive():
    assert concentration(3,20,1000,2,1)>0


def test_invalid_unit_input():
    with pytest.raises(ValueError): PlumeSimulator()(np.array([[1.2,0,0,0]]))
